package energetskisistem;

import java.awt.Color;

public class VodenaPovrs extends Parcela {

	public VodenaPovrs(Plac o) {
		super(String.valueOf('~'), Color.CYAN, o);
	}

}
