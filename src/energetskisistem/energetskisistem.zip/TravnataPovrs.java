package energetskisistem;

import java.awt.Color;

public class TravnataPovrs extends Parcela {

	public TravnataPovrs(Plac o) {
		super(String.valueOf('"'), Color.GREEN, o);
		
	}

	

}
